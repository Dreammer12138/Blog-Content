#!/usr/bin/python3
# -*- coding:utf-8 -*-

from prettytable import PrettyTable

class Node:
    Next = None
    def __init__(self, Adr, Size, Next = None):
        self.Adr = Adr
        self.Size = Size
        self.Next = Next
class Link:
    Head = None
    length = 0
    def append(self, node):
        item = node
        if not self.Head:
            self.Head = item
            self.length += 1
        else:
            temp = self.Head
            while temp.Next:
                temp = temp.Next
            temp.Next = item
            self.length += 1
    def push(self, Adr = None):
        temp = None
        if not Adr:
            if not self.Head:
                return None
            else:
                temp = self.Head
                self.Head = self.Head.Next
                return temp
            self.length -= 1
        else:
            t = self.Head
            if Adr == t.Adr:
                temp = t
                self.Head = t.Next
                return temp
            else:
                while t.Next:
                    if t.Next.Adr == Adr:
                        temp = t.Next
                        t.Next = t.Next.Next
                        return temp
                    t = t.Next
        return temp


head1 = Link()
head2 = Link()
assign1 = Link()
assign2 = Link()

def init() -> '初始化':
    head1.append(Node(0, 32767))
    head2.append(Node(0, 32767))
    
def assignment1(Size) -> '首次试应算法':
    p = head1.Head
    res = None
    if Size == p.Size:
        res = head1.push()
        res.Next = None
    elif Size < p.Size:
        res = Node(p.Adr, Size)
        p.Adr += Size
        p.Size -= Size
    elif head1.length > 1:
        while p.Next:
            if Size == p.Next.Size:
                res = p.Next
                p.Next = p.Next.Next
                res.Next = None
                head1.length -= 1
                break
            elif Size < p.Next.Size:
                res = Node(p.Next.Adr, Size)
                p.Next.Adr += Size
                p.Next.Size -= Size
                break
            p = p.Next
    assign1.append(res)
    return res

def occupation1(Adr, Size):
    a = assign1.Head
    while a:
        if Adr == a.Adr:
            if Size < a.Size:
                a.Adr = Adr + Size
                a.Size -= Size
                break
            else:
                if Size > a.Size:
                    occupation1(a.Adr + a.Size, Size - a.Size)
                assign1.push(a.Adr)
                break
        elif Adr > a.Adr and Adr < a.Adr + a.Size:
            if Adr + Size < a.Size + a.Adr:
                temp = Node(Adr + Size, a.Adr + a.Size - Adr - Size, a.Next)
                a.Next = temp
                a.Size = Adr - a.Adr
                assign1.length += 1
                break
            else:
                if Size + Adr >  a.Size + a.Adr:
                    occupation1(a.Adr + a.Size, Size - a.Size + Adr)
                a.Size = Adr
                break
        a = a.Next

def Recovery1(Adr, Size):
    h = head1.Head
    if Adr < head1.Head.Adr:
        if Adr + Size == head1.Head.Adr:
            head1.Head.Adr = Adr
            head1.Head.Size += Size
        else:
            head1.Head = Node(Adr, Size, head1.Head)
            head1.length += 1
    elif Adr == head1.Head.Adr + head1.Head.Size:
        head1.Head.Size += Size
    else:
        while h.Next:
            if Adr < h.Next.Adr:
                if Adr + Size == h.Next.Adr:
                    h.Next.Adr = Adr
                    h.Next.Size += Size
                    return
                else:
                    h.Next = Node(Adr, Size, h.Next)
                    head1.length += 1
                    return
            h = h.Next
        head1.append(Node(Adr, Size))

def acceptment1(Adr, Size):
    occupation1(Adr, Size)
    Recovery1(Adr,Size)

def assignment2(Size):
    adr_temp = head2.Head.Adr
    size_temp = head2.Head.Size

    p = head2.Head.Next
    while p:
        if Size < p.Size and p.Size < size_temp:
            size_temp = p.Size
        p = p.Next
    
    p = head2.Head
    while p:
        if p.Adr == adr_temp:
            assign2.append(Node(p.Adr, Size))
            p.Adr += Size
            p.Size -= Size
        p = p.Next

def Recovery2(Adr, Size):
    h = head2.Head
    while h:
        if Adr < h.Adr and Adr + Size == h.Adr:
            h.Adr = Adr
            h.Size += Size
            return
        elif Adr == h.Adr + h.Size:
            h.Size += Size
            return
        h = h.Next

    h = head2.Head
    if Size <= h.Adr:
        head2.Head = Node(Adr, Size, h)
        return
    else:
        if h.Next:
            while h.Next:
                if Size < h.Next.Adr:
                    h.Next = Node(Adr, Size, h.Next)
                    return
                h = h.Next
        else:
            head2.append(Node(Adr, Size))



def occupation2(Adr, Size):
    a = assign2.Head
    while a:
        if a.Adr == Adr:
            if Size < a.Size:
                a.Adr = Adr + Size
                a.Size -= Size
            else:
                if Size > a.Size:
                    occupation2(a.Adr + a.Size, Size - a.Size)
                assign2.push(a.Adr)
        elif Adr > a.Adr and Adr < a.Adr + a.Size:
            if Adr + Size < a.Size + a.Adr:
                temp = Node(Adr + Size, a.Adr + a.Size - Adr - Size, a.Next)
                a.Next = temp
                a.Size = Adr - a.Adr
                assign2.length += 1
            else:
                s = a.Size
                a.Size = Adr - a.Adr
                if Size + Adr > s + a.Adr:
                    occupation2(s + a.Adr, Adr + Size - s - a.Adr)
        a = a.Next
        

def acceptment2(Adr, Size):
    occupation2(Adr, Size)
    Recovery2(Adr, Size)
    
def check(assign, Adr, Size) -> "检查":
    a = assign.Head
    t = assign.Head
    if Adr < 0 or Size <= 0:
        return False
    while a:
        if Adr >= a.Adr and Adr < (a.Adr + a.Size):
            if (Adr + Size) <= (a.Adr + a.Size):
                return True
            else:
                while t:
                    if t.Adr == a.Adr + a.Size:
                        if check(assign, t.Adr, Size + Adr - a.Size):
                            return True
                        else:
                            return False
                    t = t.Next
        a = a.Next
    print("[Error]指定的内存空间过大")
    return False

def menu1() -> '选项菜单':
    t1 = PrettyTable()
    t1.field_names = ["选项id", "选项内容"]
    t1.add_row(["1", "最先适应算法"])
    t1.add_row(["2", "最佳适应算法"])
    t1.add_row(["3", "退出"])
    print(t1.get_string())
    choose = int(input("请选择："))
    if choose == 3:
        return
    menu2(choose)
        

def menu2(alg) -> '选项菜单':
    t2 = PrettyTable()
    t2.field_names = ["选项id", "选项内容"]
    t2.add_row(["1", "分配内存"])
    t2.add_row(["2", "回收内存"])
    t2.add_row(["3", "查看内存"])
    t2.add_row(["4", "返回"])
    print(t2.get_string())
    choose = int(input("请选择："))
    choose_Algorithm(alg, choose)

def Output(he):
    num = 1
    out = PrettyTable()
    out.field_names = ["编号", "首地址", "尾地址", "大小"]
    h = he.Head
    while h:
        out.add_row([num, h.Adr, h.Adr + h.Size - 1, h.Size])
        h = h.Next
        num += 1
    print(out)
    

def choose_Algorithm(alg, ch):
    if ch == 1:
        Size = int(input("请输入分配空间大小："))
        if alg == 1:
            assignment1(Size)
        elif alg == 2:
            assignment2(Size)
    if ch == 2:
        Adr = int(input("请输入首地址："))
        Size = int(input("请输入空间大小："))
        if alg == 1:
            if not check(assign1, Adr, Size):
                return
            acceptment1(Adr, Size)
        elif alg == 2:
            if not check(assign2, Adr, Size):
                return
            acceptment2(Adr, Size)
    if ch == 3:
        if alg == 1:
            Output(head1)
        elif alg == 2:
            Output(head2)
    menu1()

if __name__ == "__main__":
    init()
    menu1()
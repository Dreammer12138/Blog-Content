#!/usr/bin/python3
# -*- coding:utf-8 -*-

from prettytable import PrettyTable

# 节点类
class Node:
    def __init__(self, NEEDTIME, STATE, NAME, PRIO = 0, ROUND = 0, CPUTIME = 0, count = 0, _pNEXT = None):
        self.NAME       = NAME
        self.PRIO       = PRIO
        self.ROUND      = ROUND
        self.CPUTIME    = CPUTIME
        self.NEEDTIME   = NEEDTIME
        self.STATE      = STATE
        self.count      = count
        self._NEXT      = _pNEXT

# 链表类
class Link:
    Head = None
    length = 0
    
    # 将节点添加到尾部
    def append(self, node):
        item = node
        if not self.Head:
            self.Head = item
            self.length += 1
        else:
            temp = self.Head
            while temp._NEXT:
                temp = temp._NEXT
            temp._NEXT = item
            self.length += 1

    # push节点
    def push(self):
        if not self.Head:
            return None
        else:
            temp = self.Head
            self.Head = self.Head._NEXT
            return temp
        self.length -= 1

# 实例化对象
RUN = Link()
READY = Link()
FINISH = Link()

# 按优先级构造链表
def PrioCreate(num):
    print("请输入进程名称和所需时间")
    for i in range(0, num):
        name,needtime = map(str, input().split())
        needtime = int(needtime)
        node = Node(
            NEEDTIME = needtime, 
            NAME = name,
            STATE = 'W',
            PRIO = 50 - needtime
        )

        temp = READY.Head
        if not temp:
            READY.append(node)
            continue
        else:
            if node.PRIO >= temp.PRIO:
                node._NEXT = temp
                READY.Head = node
                READY.length += 1
            else:
                while temp:
                    if temp._NEXT:
                        if node.PRIO >= temp._NEXT.PRIO:
                            node._NEXT = temp._NEXT
                            temp._NEXT = node
                            READY.length += 1
                            break
                    else:
                        READY.append(node)
                        break
                    temp = temp._NEXT

# 构造链表
def RoundCreate(num):
    print("请输入进程名称和所需时间")
    for i in range(0, num):
        name,needtime = map(str, input().split())
        needtime = int(needtime)
        node = Node(
            NEEDTIME = needtime,
            NAME = name,
            STATE = 'W',
            ROUND = 2
        )
        READY.append(node)

# 优先算法
def Priority():
    RUN.append(READY.push())
    if RUN.Head:
        RUN.Head.STATE = 'R'
        RUN.Head._NEXT = None
    else:
        return

    RUN.Head.PRIO -= 1
    RUN.Head.CPUTIME += 1
    RUN.Head.NEEDTIME -= 1
    if RUN.Head.NEEDTIME == 0:
        RUN.Head.STATE = 'F'
        RUN.Head.count += 1
        FINISH.append(RUN.push())
    else:
        RUN.Head.STATE = 'W'
        RUN.Head.count += 1
        node = RUN.push()
        temp = READY.Head
        if not temp:
            READY.append(node)
        else:
            if node.PRIO >= temp.PRIO:
                node._NEXT = temp
                READY.Head = node
                READY.length += 1
            else:
                while temp:
                    if temp._NEXT:
                        if node.PRIO >= temp._NEXT.PRIO:
                            node._NEXT = temp._NEXT
                            temp._NEXT = node
                            READY.length += 1
                            break
                    else:
                        READY.append(node)
                        break
                    temp = temp._NEXT
    Output()
    Priority()

# 轮转法
def Round():
    RUN.append(READY.push())
    if RUN.Head:
        RUN.Head.STATE = 'R'
        RUN.Head._NEXT = None
    else:
        return
    
    RUN.Head.count += 1
    RUN.Head.CPUTIME += 1
    RUN.Head.NEEDTIME -= 1
    if RUN.Head.NEEDTIME == 0:
        RUN.Head.STATE = 'F'
        FINISH.append(RUN.push())
    else:
        RUN.Head.STATE = 'W'
        READY.append(RUN.push())
    Output()
    Round()

# 输出
def Output():
    t = PrettyTable()
    t.field_names = ["进程", "优先级", "轮数", "CPU时间", "需要时间", "进程状态", "计数器"]
    node = RUN.Head
    while node:
        t.add_row([node.NAME, node.PRIO, node.ROUND, node.CPUTIME, node.NEEDTIME, node.STATE, node.count])
        node = node._NEXT
    node = READY.Head
    while node:
        t.add_row([node.NAME, node.PRIO, node.ROUND, node.CPUTIME, node.NEEDTIME, node.STATE, node.count])
        node = node._NEXT
    node = FINISH.Head
    while node:
        t.add_row([node.NAME, node.PRIO, node.ROUND, node.CPUTIME, node.NEEDTIME, node.STATE, node.count])
        node = node._NEXT
    print(t.get_string())

if __name__ == '__main__':
    process_num = input("请输入进程数：")
    pattern = input("请输入进程调度方法（P/R）:")

    switch = {
        'p': lambda num: (
            PrioCreate(int(num)),
            Output(),
            Priority()
        ),
        'P': lambda num: (
            PrioCreate(int(num)),
            Output(),
            Priority()
        ),
        'r': lambda num: (
            RoundCreate(int(num)),
            Output(),
            Round()
        ),
        'R': lambda num: (
            RoundCreate(int(num)),
            Output(),
            Round()
        ),
    }
    switch[pattern](process_num)

    Output()
